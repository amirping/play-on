var app = angular.module('myapp', [])
.controller('mainctrl',['$scope','$http','$timeout',function($scope,$http,$timeout){
  $scope.resultreturn="sa7a fererererere";
  $scope.sendreq=function()
  {
    return false;
  }
}]);
